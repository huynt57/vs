<?php

/**
 * @category   Yii
 * @package    EHttp
 * @subpackage Client
 * @copyright  Copyright (c) 2010 Antonio Ramirez
 * @license    http://creativecommons.org/licenses/BSD/    New BSD License
 */
class EHttpClientException extends CException
{}
